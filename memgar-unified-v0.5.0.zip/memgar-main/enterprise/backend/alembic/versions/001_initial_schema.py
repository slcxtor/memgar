"""Initial database schema

Revision ID: 001_initial_schema
Revises: 
Create Date: 2026-04-05 12:00:00.000000

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision: str = '001_initial_schema'
down_revision: Union[str, None] = None
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    """Create initial database schema."""
    
    # Organizations table
    op.create_table(
        'organizations',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('name', sa.String(length=255), nullable=False),
        sa.Column('slug', sa.String(length=100), nullable=False),
        sa.Column('plan', sa.Enum('FREE', 'DEVELOPER', 'BUSINESS', 'ENTERPRISE', name='organizationplan'), nullable=True),
        sa.Column('max_users', sa.Integer(), nullable=True),
        sa.Column('max_api_calls_per_month', sa.Integer(), nullable=True),
        sa.Column('max_agents', sa.Integer(), nullable=True),
        sa.Column('is_active', sa.Boolean(), nullable=True),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=True),
        sa.Column('updated_at', sa.DateTime(timezone=True), nullable=True),
        sa.PrimaryKeyConstraint('id')
    )
    op.create_index(op.f('ix_organizations_slug'), 'organizations', ['slug'], unique=True)
    
    # Users table
    op.create_table(
        'users',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('email', sa.String(length=255), nullable=False),
        sa.Column('username', sa.String(length=100), nullable=False),
        sa.Column('full_name', sa.String(length=255), nullable=True),
        sa.Column('hashed_password', sa.String(length=255), nullable=False),
        sa.Column('is_active', sa.Boolean(), nullable=True),
        sa.Column('is_verified', sa.Boolean(), nullable=True),
        sa.Column('role', sa.Enum('ADMIN', 'SECURITY_ANALYST', 'DEVELOPER', 'AUDITOR', 'USER', name='userrole'), nullable=True),
        sa.Column('organization_id', sa.Integer(), nullable=False),
        sa.Column('last_login', sa.DateTime(timezone=True), nullable=True),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=True),
        sa.Column('updated_at', sa.DateTime(timezone=True), nullable=True),
        sa.ForeignKeyConstraint(['organization_id'], ['organizations.id'], ),
        sa.PrimaryKeyConstraint('id')
    )
    op.create_index(op.f('ix_users_email'), 'users', ['email'], unique=True)
    op.create_index(op.f('ix_users_username'), 'users', ['username'], unique=True)
    
    # API Keys table
    op.create_table(
        'api_keys',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('name', sa.String(length=255), nullable=False),
        sa.Column('key_hash', sa.String(length=255), nullable=False),
        sa.Column('user_id', sa.Integer(), nullable=False),
        sa.Column('organization_id', sa.Integer(), nullable=False),
        sa.Column('scopes', sa.JSON(), nullable=True),
        sa.Column('rate_limit_per_minute', sa.Integer(), nullable=True),
        sa.Column('is_active', sa.Boolean(), nullable=True),
        sa.Column('last_used', sa.DateTime(timezone=True), nullable=True),
        sa.Column('expires_at', sa.DateTime(timezone=True), nullable=True),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=True),
        sa.Column('updated_at', sa.DateTime(timezone=True), nullable=True),
        sa.ForeignKeyConstraint(['organization_id'], ['organizations.id'], ),
        sa.ForeignKeyConstraint(['user_id'], ['users.id'], ),
        sa.PrimaryKeyConstraint('id')
    )
    op.create_index(op.f('ix_api_keys_key_hash'), 'api_keys', ['key_hash'], unique=True)
    
    # Analysis Logs table
    op.create_table(
        'analysis_logs',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('organization_id', sa.Integer(), nullable=False),
        sa.Column('user_id', sa.Integer(), nullable=True),
        sa.Column('api_key_id', sa.Integer(), nullable=True),
        sa.Column('content_hash', sa.String(length=64), nullable=True),
        sa.Column('content_preview', sa.String(length=500), nullable=True),
        sa.Column('content_length', sa.Integer(), nullable=True),
        sa.Column('decision', sa.String(length=20), nullable=True),
        sa.Column('risk_score', sa.Integer(), nullable=True),
        sa.Column('threat_count', sa.Integer(), nullable=True),
        sa.Column('threats_detected', sa.JSON(), nullable=True),
        sa.Column('analysis_time_ms', sa.Integer(), nullable=True),
        sa.Column('layers_used', sa.JSON(), nullable=True),
        sa.Column('source_type', sa.String(length=50), nullable=True),
        sa.Column('source_id', sa.String(length=255), nullable=True),
        sa.Column('ip_address', sa.String(length=45), nullable=True),
        sa.Column('user_agent', sa.String(length=500), nullable=True),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=True),
        sa.ForeignKeyConstraint(['api_key_id'], ['api_keys.id'], ),
        sa.ForeignKeyConstraint(['organization_id'], ['organizations.id'], ),
        sa.ForeignKeyConstraint(['user_id'], ['users.id'], ),
        sa.PrimaryKeyConstraint('id')
    )
    op.create_index(op.f('ix_analysis_logs_content_hash'), 'analysis_logs', ['content_hash'])
    op.create_index(op.f('ix_analysis_logs_created_at'), 'analysis_logs', ['created_at'])
    op.create_index(op.f('ix_analysis_logs_decision'), 'analysis_logs', ['decision'])
    op.create_index(op.f('ix_analysis_logs_risk_score'), 'analysis_logs', ['risk_score'])
    op.create_index(op.f('ix_analysis_logs_source_id'), 'analysis_logs', ['source_id'])
    op.create_index('ix_analysis_org_created', 'analysis_logs', ['organization_id', 'created_at'])
    op.create_index('ix_analysis_decision_created', 'analysis_logs', ['decision', 'created_at'])
    
    # Audit Events table
    op.create_table(
        'audit_events',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('event_type', sa.Enum('ANALYSIS_REQUEST', 'THREAT_DETECTED', 'THREAT_BLOCKED', 'USER_LOGIN', 'USER_LOGOUT', 'SETTINGS_CHANGED', 'API_KEY_CREATED', 'API_KEY_REVOKED', 'POLICY_UPDATED', name='auditeventtype'), nullable=False),
        sa.Column('event_description', sa.Text(), nullable=True),
        sa.Column('user_id', sa.Integer(), nullable=True),
        sa.Column('organization_id', sa.Integer(), nullable=False),
        sa.Column('ip_address', sa.String(length=45), nullable=True),
        sa.Column('user_agent', sa.String(length=500), nullable=True),
        sa.Column('request_id', sa.String(length=100), nullable=True),
        sa.Column('metadata', sa.JSON(), nullable=True),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=True),
        sa.ForeignKeyConstraint(['organization_id'], ['organizations.id'], ),
        sa.ForeignKeyConstraint(['user_id'], ['users.id'], ),
        sa.PrimaryKeyConstraint('id')
    )
    op.create_index(op.f('ix_audit_events_created_at'), 'audit_events', ['created_at'])
    op.create_index(op.f('ix_audit_events_event_type'), 'audit_events', ['event_type'])
    op.create_index(op.f('ix_audit_events_request_id'), 'audit_events', ['request_id'])
    op.create_index('ix_audit_org_created', 'audit_events', ['organization_id', 'created_at'])
    op.create_index('ix_audit_type_created', 'audit_events', ['event_type', 'created_at'])
    
    # Security Policies table
    op.create_table(
        'security_policies',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('organization_id', sa.Integer(), nullable=False),
        sa.Column('name', sa.String(length=255), nullable=False),
        sa.Column('description', sa.Text(), nullable=True),
        sa.Column('enabled_threat_categories', sa.JSON(), nullable=True),
        sa.Column('custom_patterns', sa.JSON(), nullable=True),
        sa.Column('whitelist_patterns', sa.JSON(), nullable=True),
        sa.Column('blacklist_patterns', sa.JSON(), nullable=True),
        sa.Column('block_threshold', sa.Integer(), nullable=True),
        sa.Column('quarantine_threshold', sa.Integer(), nullable=True),
        sa.Column('is_active', sa.Boolean(), nullable=True),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=True),
        sa.Column('updated_at', sa.DateTime(timezone=True), nullable=True),
        sa.ForeignKeyConstraint(['organization_id'], ['organizations.id'], ),
        sa.PrimaryKeyConstraint('id'),
        sa.UniqueConstraint('organization_id', 'name', name='uq_org_policy_name')
    )


def downgrade() -> None:
    """Drop all tables."""
    op.drop_table('security_policies')
    op.drop_table('audit_events')
    op.drop_table('analysis_logs')
    op.drop_table('api_keys')
    op.drop_table('users')
    op.drop_table('organizations')
