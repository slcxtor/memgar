"""
Memgar Enterprise - Analysis API
=================================

Content analysis endpoints.
"""

from datetime import datetime
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, status, Request
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session

from memgar import Memgar
from memgar.models import Decision

from app.database.models import User, Organization


router = APIRouter()


# =============================================================================
# REQUEST/RESPONSE MODELS
# =============================================================================

class AnalysisRequest(BaseModel):
    """Analysis request payload."""
    content: str = Field(..., min_length=1, max_length=1_000_000)
    source_type: Optional[str] = Field(default="api", max_length=50)
    source_id: Optional[str] = Field(default=None, max_length=255)
    metadata: Optional[dict] = Field(default_factory=dict)


class ThreatInfo(BaseModel):
    """Threat information in response."""
    id: str
    name: str
    severity: str
    category: str
    matched_text: str
    confidence: float


class AnalysisResponse(BaseModel):
    """Analysis response."""
    request_id: str
    decision: str
    risk_score: int
    threat_count: int
    threats: list[ThreatInfo]
    explanation: str
    analysis_time_ms: float
    layers_used: list[str]
    timestamp: datetime


class BatchAnalysisRequest(BaseModel):
    """Batch analysis request."""
    entries: list[AnalysisRequest] = Field(..., min_items=1, max_items=100)


class BatchAnalysisResponse(BaseModel):
    """Batch analysis response."""
    total_entries: int
    clean_entries: int
    threat_entries: int
    quarantine_entries: int
    results: list[AnalysisResponse]
    total_time_ms: float


# =============================================================================
# DEPENDENCIES
# =============================================================================

from app.auth.dependencies import (
    get_current_user,
    get_current_organization,
    RequireAnalysisWrite,
)
from app.database.session import get_db
from sqlalchemy.orm import Session


# =============================================================================
# ENDPOINTS
# =============================================================================

@router.post(
    "/analyze",
    response_model=AnalysisResponse,
    summary="Analyze content for threats",
    description="Analyze a single piece of content for memory poisoning threats."
)
async def analyze_content(
    request: Request,
    payload: AnalysisRequest,
    current_user: User = Depends(get_current_user),
    organization: Organization = Depends(get_current_organization),
    db: Session = Depends(get_db),
):
    """
    Analyze content for memory poisoning threats.
    
    Returns detailed analysis including:
    - Decision (allow/block/quarantine)
    - Risk score (0-100)
    - Detected threats
    - Explanation
    """
    # Get request ID
    request_id = getattr(request.state, "request_id", "unknown")
    
    # Initialize Memgar
    mg = Memgar()
    
    # Perform analysis
    result = mg.analyze(payload.content)
    
    # Format threats
    threats = [
        ThreatInfo(
            id=t.threat.id,
            name=t.threat.name,
            severity=t.threat.severity.value,
            category=t.threat.category.value,
            matched_text=t.matched_text,
            confidence=t.confidence,
        )
        for t in result.threats
    ]
    
    # TODO: Log analysis to database
    # TODO: Emit metrics
    # TODO: Trigger alerts if critical
    
    return AnalysisResponse(
        request_id=request_id,
        decision=result.decision.value,
        risk_score=result.risk_score,
        threat_count=len(result.threats),
        threats=threats,
        explanation=result.explanation,
        analysis_time_ms=result.analysis_time_ms,
        layers_used=result.layers_used,
        timestamp=datetime.utcnow(),
    )


@router.post(
    "/analyze/batch",
    response_model=BatchAnalysisResponse,
    summary="Batch analyze multiple entries",
    description="Analyze multiple content entries in a single request."
)
async def batch_analyze(
    payload: BatchAnalysisRequest,
    user = Depends(get_current_user),
):
    """
    Batch analyze multiple content entries.
    
    Efficiently processes up to 100 entries in parallel.
    """
    from memgar import Scanner
    from memgar.models import MemoryEntry
    
    # Convert to MemoryEntry objects
    entries = [
        MemoryEntry(
            content=req.content,
            source_type=req.source_type or "api",
            source_id=req.source_id,
            metadata=req.metadata or {},
        )
        for req in payload.entries
    ]
    
    # Scan entries
    scanner = Scanner()
    scan_result = scanner.scan_memories_parallel(entries)
    
    # Format results
    results = []
    for analysis_result in scan_result.results:
        threats = [
            ThreatInfo(
                id=t.threat.id,
                name=t.threat.name,
                severity=t.threat.severity.value,
                category=t.threat.category.value,
                matched_text=t.matched_text,
                confidence=t.confidence,
            )
            for t in analysis_result.threats
        ]
        
        results.append(AnalysisResponse(
            request_id=f"batch_{len(results)}",
            decision=analysis_result.decision.value,
            risk_score=analysis_result.risk_score,
            threat_count=len(analysis_result.threats),
            threats=threats,
            explanation=analysis_result.explanation,
            analysis_time_ms=analysis_result.analysis_time_ms,
            layers_used=analysis_result.layers_used,
            timestamp=datetime.utcnow(),
        ))
    
    return BatchAnalysisResponse(
        total_entries=scan_result.total_entries,
        clean_entries=scan_result.clean_entries,
        threat_entries=scan_result.threat_entries,
        quarantine_entries=scan_result.quarantine_entries,
        results=results,
        total_time_ms=scan_result.scan_time_ms,
    )


@router.get(
    "/stats",
    summary="Get analysis statistics",
    description="Get overall analysis statistics for the organization."
)
async def get_analysis_stats(
    user = Depends(get_current_user),
):
    """
    Get analysis statistics.
    
    Returns aggregated statistics about analyses performed.
    """
    # TODO: Query database for stats
    
    return {
        "total_analyses": 0,
        "threats_detected": 0,
        "blocked_content": 0,
        "avg_risk_score": 0.0,
        "top_threats": [],
    }


__all__ = ["router"]
