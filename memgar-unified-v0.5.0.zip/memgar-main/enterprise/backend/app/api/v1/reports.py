"""
Memgar Enterprise - Reports API
================================

Report generation and export endpoints.
"""

from fastapi import APIRouter, Depends
from app.api.v1.analysis import get_current_user

router = APIRouter()


@router.get("/")
async def list_reports(user = Depends(get_current_user)):
    """List available reports."""
    return {"reports": []}


@router.post("/generate")
async def generate_report(user = Depends(get_current_user)):
    """Generate a new report."""
    return {"status": "generating"}


@router.get("/{report_id}")
async def get_report(report_id: int, user = Depends(get_current_user)):
    """Get specific report."""
    return {"report_id": report_id}


__all__ = ["router"]
