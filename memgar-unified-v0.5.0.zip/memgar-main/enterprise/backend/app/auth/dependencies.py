"""
Memgar Enterprise - Authentication Dependencies
================================================

FastAPI dependencies for authentication and authorization.
"""

from typing import Optional

from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from sqlalchemy.orm import Session

from app.auth.jwt import decode_token, verify_token_type
from app.auth.rbac import Permission, has_permission
from app.database.models import User, Organization, UserRole
from app.database.session import get_db


# =============================================================================
# SECURITY SCHEMES
# =============================================================================

# HTTP Bearer token scheme
security = HTTPBearer()


# =============================================================================
# AUTHENTICATION DEPENDENCIES
# =============================================================================

async def get_current_user(
    credentials: HTTPAuthorizationCredentials = Depends(security),
    db: Session = Depends(get_db),
) -> User:
    """
    Get current authenticated user from JWT token.
    
    Args:
        credentials: HTTP Bearer token
        db: Database session
    
    Returns:
        Authenticated user
    
    Raises:
        HTTPException: If token is invalid or user not found
    """
    # Extract token
    token = credentials.credentials
    
    # Decode and validate token
    payload = decode_token(token)
    if payload is None:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid authentication token",
            headers={"WWW-Authenticate": "Bearer"},
        )
    
    # Verify token type (must be access token)
    if not verify_token_type(payload, "access"):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid token type",
            headers={"WWW-Authenticate": "Bearer"},
        )
    
    # Get user ID from token
    user_id: int = payload.get("sub")
    if user_id is None:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid token payload",
            headers={"WWW-Authenticate": "Bearer"},
        )
    
    # Fetch user from database
    user = db.query(User).filter(User.id == user_id).first()
    if user is None:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="User not found",
            headers={"WWW-Authenticate": "Bearer"},
        )
    
    # Check if user is active
    if not user.is_active:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="User account is disabled",
        )
    
    return user


async def get_current_active_user(
    current_user: User = Depends(get_current_user),
) -> User:
    """
    Get current active user.
    
    This is an alias for get_current_user for clarity.
    """
    return current_user


async def get_current_organization(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
) -> Organization:
    """
    Get current user's organization.
    
    Args:
        current_user: Authenticated user
        db: Database session
    
    Returns:
        User's organization
    
    Raises:
        HTTPException: If organization not found or inactive
    """
    org = db.query(Organization).filter(
        Organization.id == current_user.organization_id
    ).first()
    
    if org is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Organization not found",
        )
    
    if not org.is_active:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Organization is disabled",
        )
    
    return org


# =============================================================================
# AUTHORIZATION DEPENDENCIES
# =============================================================================

class RequirePermission:
    """
    Dependency class to require specific permission.
    
    Usage:
        @app.get("/admin/users")
        async def list_users(
            user: User = Depends(RequirePermission(Permission.USER_VIEW))
        ):
            return {"users": [...]}
    """
    
    def __init__(self, permission: Permission):
        self.permission = permission
    
    async def __call__(
        self,
        current_user: User = Depends(get_current_user),
    ) -> User:
        """Check if user has required permission."""
        if not has_permission(current_user.role, self.permission):
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"Permission required: {self.permission.value}",
            )
        return current_user


class RequireRole:
    """
    Dependency class to require specific role.
    
    Usage:
        @app.get("/admin/settings")
        async def get_settings(
            user: User = Depends(RequireRole(UserRole.ADMIN))
        ):
            return {"settings": {...}}
    """
    
    def __init__(self, *roles: UserRole):
        self.roles = set(roles)
    
    async def __call__(
        self,
        current_user: User = Depends(get_current_user),
    ) -> User:
        """Check if user has required role."""
        if current_user.role not in self.roles:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"Role required: {', '.join(r.value for r in self.roles)}",
            )
        return current_user


# =============================================================================
# CONVENIENCE DEPENDENCIES
# =============================================================================

# Require admin role
RequireAdmin = RequireRole(UserRole.ADMIN)

# Require security analyst or admin
RequireSecurityAnalyst = RequireRole(UserRole.SECURITY_ANALYST, UserRole.ADMIN)

# Common permission requirements
RequireAnalysisRead = RequirePermission(Permission.ANALYSIS_READ)
RequireAnalysisWrite = RequirePermission(Permission.ANALYSIS_WRITE)
RequireDashboardView = RequirePermission(Permission.DASHBOARD_VIEW)
RequireReportCreate = RequirePermission(Permission.REPORT_CREATE)
RequireAuditView = RequirePermission(Permission.AUDIT_VIEW)
RequireUserManagement = RequirePermission(Permission.USER_CREATE)


__all__ = [
    "security",
    "get_current_user",
    "get_current_active_user",
    "get_current_organization",
    "RequirePermission",
    "RequireRole",
    "RequireAdmin",
    "RequireSecurityAnalyst",
    "RequireAnalysisRead",
    "RequireAnalysisWrite",
    "RequireDashboardView",
    "RequireReportCreate",
    "RequireAuditView",
    "RequireUserManagement",
]
