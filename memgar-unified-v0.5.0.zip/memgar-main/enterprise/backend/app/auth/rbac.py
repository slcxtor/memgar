"""
Memgar Enterprise - Role-Based Access Control (RBAC)
=====================================================

Permission management and access control.
"""

from enum import Enum
from typing import Set

from app.database.models import UserRole


# =============================================================================
# PERMISSION DEFINITIONS
# =============================================================================

class Permission(str, Enum):
    """System permissions."""
    
    # Analysis permissions
    ANALYSIS_READ = "analysis:read"
    ANALYSIS_WRITE = "analysis:write"
    ANALYSIS_DELETE = "analysis:delete"
    
    # Dashboard permissions
    DASHBOARD_VIEW = "dashboard:view"
    DASHBOARD_ADMIN = "dashboard:admin"
    
    # Report permissions
    REPORT_VIEW = "report:view"
    REPORT_CREATE = "report:create"
    REPORT_EXPORT = "report:export"
    
    # Audit permissions
    AUDIT_VIEW = "audit:view"
    AUDIT_EXPORT = "audit:export"
    
    # Policy permissions
    POLICY_VIEW = "policy:view"
    POLICY_CREATE = "policy:create"
    POLICY_UPDATE = "policy:update"
    POLICY_DELETE = "policy:delete"
    
    # User management
    USER_VIEW = "user:view"
    USER_CREATE = "user:create"
    USER_UPDATE = "user:update"
    USER_DELETE = "user:delete"
    
    # Organization management
    ORG_VIEW = "org:view"
    ORG_UPDATE = "org:update"
    ORG_SETTINGS = "org:settings"
    
    # API key management
    APIKEY_VIEW = "apikey:view"
    APIKEY_CREATE = "apikey:create"
    APIKEY_REVOKE = "apikey:revoke"
    
    # System administration
    SYSTEM_ADMIN = "system:admin"


# =============================================================================
# ROLE-PERMISSION MAPPING
# =============================================================================

ROLE_PERMISSIONS: dict[UserRole, Set[Permission]] = {
    # Admin: Full access to everything
    UserRole.ADMIN: {
        Permission.ANALYSIS_READ,
        Permission.ANALYSIS_WRITE,
        Permission.ANALYSIS_DELETE,
        Permission.DASHBOARD_VIEW,
        Permission.DASHBOARD_ADMIN,
        Permission.REPORT_VIEW,
        Permission.REPORT_CREATE,
        Permission.REPORT_EXPORT,
        Permission.AUDIT_VIEW,
        Permission.AUDIT_EXPORT,
        Permission.POLICY_VIEW,
        Permission.POLICY_CREATE,
        Permission.POLICY_UPDATE,
        Permission.POLICY_DELETE,
        Permission.USER_VIEW,
        Permission.USER_CREATE,
        Permission.USER_UPDATE,
        Permission.USER_DELETE,
        Permission.ORG_VIEW,
        Permission.ORG_UPDATE,
        Permission.ORG_SETTINGS,
        Permission.APIKEY_VIEW,
        Permission.APIKEY_CREATE,
        Permission.APIKEY_REVOKE,
        Permission.SYSTEM_ADMIN,
    },
    
    # Security Analyst: Analysis and reporting focus
    UserRole.SECURITY_ANALYST: {
        Permission.ANALYSIS_READ,
        Permission.ANALYSIS_WRITE,
        Permission.DASHBOARD_VIEW,
        Permission.REPORT_VIEW,
        Permission.REPORT_CREATE,
        Permission.REPORT_EXPORT,
        Permission.AUDIT_VIEW,
        Permission.POLICY_VIEW,
        Permission.POLICY_UPDATE,
    },
    
    # Developer: API access and analysis
    UserRole.DEVELOPER: {
        Permission.ANALYSIS_READ,
        Permission.ANALYSIS_WRITE,
        Permission.DASHBOARD_VIEW,
        Permission.REPORT_VIEW,
        Permission.APIKEY_VIEW,
        Permission.APIKEY_CREATE,
        Permission.POLICY_VIEW,
    },
    
    # Auditor: Read-only access to logs and reports
    UserRole.AUDITOR: {
        Permission.ANALYSIS_READ,
        Permission.DASHBOARD_VIEW,
        Permission.REPORT_VIEW,
        Permission.REPORT_EXPORT,
        Permission.AUDIT_VIEW,
        Permission.AUDIT_EXPORT,
        Permission.POLICY_VIEW,
    },
    
    # User: Basic analysis access
    UserRole.USER: {
        Permission.ANALYSIS_READ,
        Permission.ANALYSIS_WRITE,
        Permission.DASHBOARD_VIEW,
        Permission.REPORT_VIEW,
    },
}


# =============================================================================
# PERMISSION CHECKING
# =============================================================================

def get_role_permissions(role: UserRole) -> Set[Permission]:
    """
    Get all permissions for a given role.
    
    Args:
        role: User role
    
    Returns:
        Set of permissions
    """
    return ROLE_PERMISSIONS.get(role, set())


def has_permission(role: UserRole, permission: Permission) -> bool:
    """
    Check if a role has a specific permission.
    
    Args:
        role: User role
        permission: Required permission
    
    Returns:
        True if role has permission
    """
    permissions = get_role_permissions(role)
    return permission in permissions


def has_any_permission(role: UserRole, permissions: Set[Permission]) -> bool:
    """
    Check if a role has any of the specified permissions.
    
    Args:
        role: User role
        permissions: Set of permissions to check
    
    Returns:
        True if role has at least one permission
    """
    role_permissions = get_role_permissions(role)
    return bool(role_permissions.intersection(permissions))


def has_all_permissions(role: UserRole, permissions: Set[Permission]) -> bool:
    """
    Check if a role has all specified permissions.
    
    Args:
        role: User role
        permissions: Set of permissions to check
    
    Returns:
        True if role has all permissions
    """
    role_permissions = get_role_permissions(role)
    return permissions.issubset(role_permissions)


def is_admin(role: UserRole) -> bool:
    """
    Check if role has admin privileges.
    
    Args:
        role: User role
    
    Returns:
        True if role is admin
    """
    return role == UserRole.ADMIN or has_permission(role, Permission.SYSTEM_ADMIN)


def can_manage_users(role: UserRole) -> bool:
    """
    Check if role can manage users.
    
    Args:
        role: User role
    
    Returns:
        True if role can create/update/delete users
    """
    return has_permission(role, Permission.USER_CREATE) or is_admin(role)


def can_modify_policies(role: UserRole) -> bool:
    """
    Check if role can modify security policies.
    
    Args:
        role: User role
    
    Returns:
        True if role can create/update/delete policies
    """
    return has_permission(role, Permission.POLICY_UPDATE) or is_admin(role)


def can_export_data(role: UserRole) -> bool:
    """
    Check if role can export sensitive data.
    
    Args:
        role: User role
    
    Returns:
        True if role can export reports or audit logs
    """
    return (
        has_permission(role, Permission.REPORT_EXPORT) or
        has_permission(role, Permission.AUDIT_EXPORT) or
        is_admin(role)
    )


# =============================================================================
# SCOPE VALIDATION
# =============================================================================

def validate_api_scopes(scopes: list[str], required_permissions: Set[Permission]) -> bool:
    """
    Validate API key scopes against required permissions.
    
    Args:
        scopes: List of API key scopes
        required_permissions: Set of required permissions
    
    Returns:
        True if scopes satisfy permissions
    """
    # Convert scope strings to Permission enums
    try:
        scope_perms = {Permission(scope) for scope in scopes}
    except ValueError:
        return False
    
    # Check if scopes include all required permissions
    return required_permissions.issubset(scope_perms)


__all__ = [
    "Permission",
    "ROLE_PERMISSIONS",
    "get_role_permissions",
    "has_permission",
    "has_any_permission",
    "has_all_permissions",
    "is_admin",
    "can_manage_users",
    "can_modify_policies",
    "can_export_data",
    "validate_api_scopes",
]
