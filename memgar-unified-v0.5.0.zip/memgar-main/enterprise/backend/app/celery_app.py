"""
Memgar Enterprise - Celery Application
=======================================

Distributed task queue for background processing.
"""

from celery import Celery
from celery.schedules import crontab

from app.config import settings


# =============================================================================
# CELERY APPLICATION
# =============================================================================

celery_app = Celery(
    "memgar",
    broker=settings.CELERY_BROKER_URL,
    backend=settings.CELERY_RESULT_BACKEND,
    include=[
        "app.tasks.analysis",
        "app.tasks.reports",
        "app.tasks.cleanup",
    ],
)

# Celery configuration
celery_app.conf.update(
    # Task settings
    task_serializer="json",
    accept_content=["json"],
    result_serializer="json",
    timezone="UTC",
    enable_utc=True,
    
    # Task execution
    task_track_started=True,
    task_time_limit=300,  # 5 minutes
    task_soft_time_limit=240,  # 4 minutes
    task_acks_late=True,
    task_reject_on_worker_lost=True,
    
    # Result backend
    result_expires=3600,  # 1 hour
    result_backend_transport_options={
        "master_name": "mymaster",
        "visibility_timeout": 3600,
    },
    
    # Worker settings
    worker_prefetch_multiplier=4,
    worker_max_tasks_per_child=1000,
    
    # Beat schedule (periodic tasks)
    beat_schedule={
        # Clean up old analysis logs every day at 2 AM
        "cleanup-old-logs": {
            "task": "app.tasks.cleanup.cleanup_old_analysis_logs",
            "schedule": crontab(hour=2, minute=0),
            "args": (30,),  # Keep last 30 days
        },
        
        # Generate daily reports at 6 AM
        "daily-reports": {
            "task": "app.tasks.reports.generate_daily_reports",
            "schedule": crontab(hour=6, minute=0),
        },
        
        # Update threat intelligence every hour
        "update-threat-intel": {
            "task": "app.tasks.analysis.update_threat_intelligence",
            "schedule": crontab(minute=0),  # Every hour
        },
    },
)


# =============================================================================
# TASK BASE CLASS
# =============================================================================

class MemgarTask(celery_app.Task):
    """
    Base task class with error handling and logging.
    """
    
    def on_failure(self, exc, task_id, args, kwargs, einfo):
        """Handle task failure."""
        # Log error
        print(f"Task {task_id} failed: {exc}")
        
        # Send alert for critical tasks
        if self.name.startswith("app.tasks.reports"):
            # TODO: Send email/Slack notification
            pass
    
    def on_retry(self, exc, task_id, args, kwargs, einfo):
        """Handle task retry."""
        print(f"Task {task_id} retrying: {exc}")
    
    def on_success(self, retval, task_id, args, kwargs):
        """Handle task success."""
        print(f"Task {task_id} succeeded")


# Set base task class
celery_app.Task = MemgarTask


__all__ = ["celery_app"]
