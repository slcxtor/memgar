"""
Memgar Enterprise - Database Models
====================================

SQLAlchemy models for enterprise features.
"""

from datetime import datetime
from enum import Enum as PyEnum
from typing import Optional

from sqlalchemy import (
    Boolean, Column, DateTime, Enum, ForeignKey, 
    Integer, String, Text, JSON, Index, UniqueConstraint
)
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func


Base = declarative_base()


# =============================================================================
# ENUMS
# =============================================================================

class UserRole(str, PyEnum):
    """User roles for RBAC."""
    ADMIN = "admin"              # Full system access
    SECURITY_ANALYST = "security_analyst"  # View and analyze threats
    DEVELOPER = "developer"      # API access, integration
    AUDITOR = "auditor"         # Read-only access to audit logs
    USER = "user"               # Basic access


class OrganizationPlan(str, PyEnum):
    """Subscription plans."""
    FREE = "free"
    DEVELOPER = "developer"
    BUSINESS = "business"
    ENTERPRISE = "enterprise"


class AuditEventType(str, PyEnum):
    """Types of audit events."""
    ANALYSIS_REQUEST = "analysis_request"
    THREAT_DETECTED = "threat_detected"
    THREAT_BLOCKED = "threat_blocked"
    USER_LOGIN = "user_login"
    USER_LOGOUT = "user_logout"
    SETTINGS_CHANGED = "settings_changed"
    API_KEY_CREATED = "api_key_created"
    API_KEY_REVOKED = "api_key_revoked"
    POLICY_UPDATED = "policy_updated"


# =============================================================================
# ORGANIZATION & MULTI-TENANCY
# =============================================================================

class Organization(Base):
    """Organization/Company for multi-tenancy."""
    __tablename__ = "organizations"
    
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(255), nullable=False)
    slug = Column(String(100), unique=True, nullable=False, index=True)
    plan = Column(Enum(OrganizationPlan), default=OrganizationPlan.FREE)
    
    # Limits based on plan
    max_users = Column(Integer, default=1)
    max_api_calls_per_month = Column(Integer, default=1000)
    max_agents = Column(Integer, default=5)
    
    # Status
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())
    
    # Relationships
    users = relationship("User", back_populates="organization")
    api_keys = relationship("APIKey", back_populates="organization")
    analysis_logs = relationship("AnalysisLog", back_populates="organization")
    
    def __repr__(self) -> str:
        return f"<Organization(name='{self.name}', plan='{self.plan.value}')>"


# =============================================================================
# USERS & AUTHENTICATION
# =============================================================================

class User(Base):
    """User account with RBAC."""
    __tablename__ = "users"
    
    id = Column(Integer, primary_key=True, index=True)
    email = Column(String(255), unique=True, nullable=False, index=True)
    username = Column(String(100), unique=True, nullable=False, index=True)
    full_name = Column(String(255))
    
    # Authentication
    hashed_password = Column(String(255), nullable=False)
    is_active = Column(Boolean, default=True)
    is_verified = Column(Boolean, default=False)
    
    # RBAC
    role = Column(Enum(UserRole), default=UserRole.USER)
    organization_id = Column(Integer, ForeignKey("organizations.id"), nullable=False)
    
    # Timestamps
    last_login = Column(DateTime(timezone=True))
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())
    
    # Relationships
    organization = relationship("Organization", back_populates="users")
    api_keys = relationship("APIKey", back_populates="user")
    audit_events = relationship("AuditEvent", back_populates="user")
    
    def __repr__(self) -> str:
        return f"<User(email='{self.email}', role='{self.role.value}')>"


# =============================================================================
# API KEYS & ACCESS
# =============================================================================

class APIKey(Base):
    """API keys for programmatic access."""
    __tablename__ = "api_keys"
    
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(255), nullable=False)
    key_hash = Column(String(255), unique=True, nullable=False, index=True)
    
    # Ownership
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    organization_id = Column(Integer, ForeignKey("organizations.id"), nullable=False)
    
    # Permissions
    scopes = Column(JSON, default=list)  # ["analysis:read", "analysis:write", etc.]
    
    # Rate limiting
    rate_limit_per_minute = Column(Integer, default=60)
    
    # Status
    is_active = Column(Boolean, default=True)
    last_used = Column(DateTime(timezone=True))
    expires_at = Column(DateTime(timezone=True))
    
    # Timestamps
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())
    
    # Relationships
    user = relationship("User", back_populates="api_keys")
    organization = relationship("Organization", back_populates="api_keys")
    
    def __repr__(self) -> str:
        return f"<APIKey(name='{self.name}', user_id={self.user_id})>"


# =============================================================================
# ANALYSIS & THREAT TRACKING
# =============================================================================

class AnalysisLog(Base):
    """Log of all analysis requests."""
    __tablename__ = "analysis_logs"
    
    id = Column(Integer, primary_key=True, index=True)
    
    # Request info
    organization_id = Column(Integer, ForeignKey("organizations.id"), nullable=False)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=True)
    api_key_id = Column(Integer, ForeignKey("api_keys.id"), nullable=True)
    
    # Content (truncated for storage)
    content_hash = Column(String(64), index=True)  # SHA256 hash
    content_preview = Column(String(500))  # First 500 chars
    content_length = Column(Integer)
    
    # Result
    decision = Column(String(20), index=True)  # allow/block/quarantine
    risk_score = Column(Integer, index=True)
    threat_count = Column(Integer, default=0)
    threats_detected = Column(JSON, default=list)  # List of threat IDs
    
    # Performance
    analysis_time_ms = Column(Integer)
    layers_used = Column(JSON, default=list)
    
    # Metadata
    source_type = Column(String(50))  # email, chat, api, etc.
    source_id = Column(String(255), index=True)
    ip_address = Column(String(45))
    user_agent = Column(String(500))
    
    # Timestamp
    created_at = Column(DateTime(timezone=True), server_default=func.now(), index=True)
    
    # Relationships
    organization = relationship("Organization", back_populates="analysis_logs")
    
    # Indexes for performance
    __table_args__ = (
        Index("ix_analysis_org_created", "organization_id", "created_at"),
        Index("ix_analysis_decision_created", "decision", "created_at"),
    )
    
    def __repr__(self) -> str:
        return f"<AnalysisLog(decision='{self.decision}', risk_score={self.risk_score})>"


# =============================================================================
# AUDIT LOGGING
# =============================================================================

class AuditEvent(Base):
    """Audit log for compliance and security."""
    __tablename__ = "audit_events"
    
    id = Column(Integer, primary_key=True, index=True)
    
    # Event info
    event_type = Column(Enum(AuditEventType), nullable=False, index=True)
    event_description = Column(Text)
    
    # Actor
    user_id = Column(Integer, ForeignKey("users.id"), nullable=True)
    organization_id = Column(Integer, ForeignKey("organizations.id"), nullable=False)
    
    # Context
    ip_address = Column(String(45))
    user_agent = Column(String(500))
    request_id = Column(String(100), index=True)
    
    # Data
    metadata = Column(JSON, default=dict)  # Additional event data
    
    # Timestamp
    created_at = Column(DateTime(timezone=True), server_default=func.now(), index=True)
    
    # Relationships
    user = relationship("User", back_populates="audit_events")
    
    # Indexes
    __table_args__ = (
        Index("ix_audit_org_created", "organization_id", "created_at"),
        Index("ix_audit_type_created", "event_type", "created_at"),
    )
    
    def __repr__(self) -> str:
        return f"<AuditEvent(type='{self.event_type.value}', user_id={self.user_id})>"


# =============================================================================
# SECURITY POLICIES
# =============================================================================

class SecurityPolicy(Base):
    """Custom security policies per organization."""
    __tablename__ = "security_policies"
    
    id = Column(Integer, primary_key=True, index=True)
    organization_id = Column(Integer, ForeignKey("organizations.id"), nullable=False)
    
    # Policy details
    name = Column(String(255), nullable=False)
    description = Column(Text)
    
    # Configuration
    enabled_threat_categories = Column(JSON, default=list)
    custom_patterns = Column(JSON, default=list)
    whitelist_patterns = Column(JSON, default=list)
    blacklist_patterns = Column(JSON, default=list)
    
    # Thresholds
    block_threshold = Column(Integer, default=80)
    quarantine_threshold = Column(Integer, default=50)
    
    # Status
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())
    
    # Unique policy name per org
    __table_args__ = (
        UniqueConstraint("organization_id", "name", name="uq_org_policy_name"),
    )
    
    def __repr__(self) -> str:
        return f"<SecurityPolicy(name='{self.name}', org_id={self.organization_id})>"


__all__ = [
    "Base",
    "UserRole",
    "OrganizationPlan",
    "AuditEventType",
    "Organization",
    "User",
    "APIKey",
    "AnalysisLog",
    "AuditEvent",
    "SecurityPolicy",
]
