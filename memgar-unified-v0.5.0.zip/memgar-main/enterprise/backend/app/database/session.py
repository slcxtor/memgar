"""
Memgar Enterprise - Database Session Management
================================================

SQLAlchemy session factory and dependency injection.
"""

from typing import Generator

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, Session
from sqlalchemy.pool import NullPool

from app.config import settings


# =============================================================================
# ENGINE CONFIGURATION
# =============================================================================

# Create engine with connection pooling
engine = create_engine(
    settings.DATABASE_URL,
    pool_size=settings.DATABASE_POOL_SIZE,
    max_overflow=settings.DATABASE_MAX_OVERFLOW,
    pool_pre_ping=True,  # Verify connections before use
    echo=settings.DEBUG,  # Log SQL queries in debug mode
)

# Create session factory
SessionLocal = sessionmaker(
    autocommit=False,
    autoflush=False,
    bind=engine,
)


# =============================================================================
# DEPENDENCY INJECTION
# =============================================================================

def get_db() -> Generator[Session, None, None]:
    """
    Database session dependency for FastAPI.
    
    Usage:
        @app.get("/items")
        def get_items(db: Session = Depends(get_db)):
            return db.query(Item).all()
    
    Yields:
        Database session
    """
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


# =============================================================================
# UTILITIES
# =============================================================================

def init_db() -> None:
    """
    Initialize database.
    
    Creates all tables if they don't exist.
    This is typically used in development or testing.
    In production, use Alembic migrations instead.
    """
    from app.database.models import Base
    Base.metadata.create_all(bind=engine)


def reset_db() -> None:
    """
    Reset database (DROP ALL TABLES).
    
    WARNING: This will delete all data!
    Only use in development/testing.
    """
    from app.database.models import Base
    Base.metadata.drop_all(bind=engine)
    Base.metadata.create_all(bind=engine)


__all__ = [
    "engine",
    "SessionLocal",
    "get_db",
    "init_db",
    "reset_db",
]
