"""
Memgar Enterprise - FastAPI Application
========================================

Main application entry point.
"""

from contextlib import asynccontextmanager
from typing import AsyncGenerator

from fastapi import FastAPI, Request, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.gzip import GZipMiddleware
from fastapi.responses import JSONResponse
import structlog

from app.config import settings
from app.api.v1 import analysis, dashboard, reports, audit, admin, auth


# Configure structured logging
logger = structlog.get_logger()


# =============================================================================
# LIFESPAN EVENTS
# =============================================================================

@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncGenerator:
    """Application lifespan events."""
    # Startup
    logger.info("Starting Memgar Enterprise API", version=settings.APP_VERSION)
    
    # TODO: Initialize database connection pool
    # TODO: Initialize Redis connection
    # TODO: Initialize Celery worker connection
    # TODO: Start background tasks
    
    yield
    
    # Shutdown
    logger.info("Shutting down Memgar Enterprise API")
    
    # TODO: Close database connections
    # TODO: Close Redis connections
    # TODO: Stop background tasks


# =============================================================================
# APPLICATION FACTORY
# =============================================================================

def create_app() -> FastAPI:
    """Create and configure FastAPI application."""
    
    app = FastAPI(
        title=settings.APP_NAME,
        version=settings.APP_VERSION,
        description="AI Agent Memory Security Platform - Enterprise API",
        docs_url=settings.API_DOCS_URL if settings.DEBUG else None,
        redoc_url=settings.API_REDOC_URL if settings.DEBUG else None,
        openapi_url=f"{settings.API_V1_PREFIX}/openapi.json",
        lifespan=lifespan,
    )
    
    # ==========================================================================
    # MIDDLEWARE
    # ==========================================================================
    
    # CORS
    app.add_middleware(
        CORSMiddleware,
        allow_origins=settings.CORS_ORIGINS,
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )
    
    # GZip compression
    app.add_middleware(GZipMiddleware, minimum_size=1000)
    
    # Request ID middleware
    @app.middleware("http")
    async def add_request_id(request: Request, call_next):
        """Add request ID to all requests."""
        import uuid
        request_id = str(uuid.uuid4())
        request.state.request_id = request_id
        
        response = await call_next(request)
        response.headers["X-Request-ID"] = request_id
        
        return response
    
    # Logging middleware
    @app.middleware("http")
    async def log_requests(request: Request, call_next):
        """Log all requests."""
        logger.info(
            "Request started",
            method=request.method,
            path=request.url.path,
            request_id=getattr(request.state, "request_id", None),
        )
        
        response = await call_next(request)
        
        logger.info(
            "Request completed",
            method=request.method,
            path=request.url.path,
            status_code=response.status_code,
            request_id=getattr(request.state, "request_id", None),
        )
        
        return response
    
    # ==========================================================================
    # EXCEPTION HANDLERS
    # ==========================================================================
    
    @app.exception_handler(Exception)
    async def global_exception_handler(request: Request, exc: Exception):
        """Global exception handler."""
        logger.error(
            "Unhandled exception",
            exc_info=exc,
            path=request.url.path,
            request_id=getattr(request.state, "request_id", None),
        )
        
        return JSONResponse(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            content={
                "error": "Internal server error",
                "request_id": getattr(request.state, "request_id", None),
            },
        )
    
    # ==========================================================================
    # ROUTERS
    # ==========================================================================
    
    # API v1 routes
    app.include_router(
        auth.router,
        prefix=f"{settings.API_V1_PREFIX}/auth",
        tags=["Authentication"],
    )
    
    app.include_router(
        analysis.router,
        prefix=f"{settings.API_V1_PREFIX}/analysis",
        tags=["Analysis"],
    )
    
    app.include_router(
        dashboard.router,
        prefix=f"{settings.API_V1_PREFIX}/dashboard",
        tags=["Dashboard"],
    )
    
    app.include_router(
        reports.router,
        prefix=f"{settings.API_V1_PREFIX}/reports",
        tags=["Reports"],
    )
    
    app.include_router(
        audit.router,
        prefix=f"{settings.API_V1_PREFIX}/audit",
        tags=["Audit"],
    )
    
    app.include_router(
        admin.router,
        prefix=f"{settings.API_V1_PREFIX}/admin",
        tags=["Admin"],
    )
    
    # ==========================================================================
    # HEALTH CHECK
    # ==========================================================================
    
    @app.get("/health", tags=["System"])
    async def health_check():
        """Health check endpoint."""
        return {
            "status": "healthy",
            "version": settings.APP_VERSION,
            "environment": settings.ENVIRONMENT,
        }
    
    @app.get("/", tags=["System"])
    async def root():
        """Root endpoint."""
        return {
            "message": "Memgar Enterprise API",
            "version": settings.APP_VERSION,
            "docs": f"{settings.API_DOCS_URL}",
        }
    
    return app


# =============================================================================
# APPLICATION INSTANCE
# =============================================================================

app = create_app()


if __name__ == "__main__":
    import uvicorn
    
    uvicorn.run(
        "app.main:app",
        host="0.0.0.0",
        port=8000,
        reload=settings.DEBUG,
        log_level=settings.LOG_LEVEL.lower(),
    )
