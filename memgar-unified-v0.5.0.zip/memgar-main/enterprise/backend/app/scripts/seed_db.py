#!/usr/bin/env python3
"""
Memgar Enterprise - Database Seed Script
=========================================

Seeds the database with initial data for development and demo.
"""

import sys
from pathlib import Path

# Add parent directory to path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent))

from sqlalchemy.orm import Session

from app.database.session import SessionLocal
from app.database.models import (
    Organization,
    User,
    UserRole,
    OrganizationPlan,
)
from app.auth.jwt import get_password_hash


def seed_database():
    """Seed database with initial data."""
    db = SessionLocal()
    
    try:
        print("🌱 Seeding database...")
        
        # Check if already seeded
        existing_org = db.query(Organization).first()
        if existing_org:
            print("⚠️  Database already seeded. Skipping.")
            return
        
        # Create demo organization
        demo_org = Organization(
            name="Demo Organization",
            slug="demo-org",
            plan=OrganizationPlan.BUSINESS,
            max_users=10,
            max_api_calls_per_month=500000,
            max_agents=50,
            is_active=True,
        )
        db.add(demo_org)
        db.flush()
        
        print(f"✓ Created organization: {demo_org.name}")
        
        # Create admin user
        admin_user = User(
            email="admin@memgar.com",
            username="admin",
            full_name="Admin User",
            hashed_password=get_password_hash("admin123"),
            role=UserRole.ADMIN,
            organization_id=demo_org.id,
            is_active=True,
            is_verified=True,
        )
        db.add(admin_user)
        
        print(f"✓ Created admin user: {admin_user.email}")
        
        # Create security analyst user
        analyst_user = User(
            email="analyst@memgar.com",
            username="analyst",
            full_name="Security Analyst",
            hashed_password=get_password_hash("analyst123"),
            role=UserRole.SECURITY_ANALYST,
            organization_id=demo_org.id,
            is_active=True,
            is_verified=True,
        )
        db.add(analyst_user)
        
        print(f"✓ Created analyst user: {analyst_user.email}")
        
        # Create developer user
        dev_user = User(
            email="developer@memgar.com",
            username="developer",
            full_name="Developer User",
            hashed_password=get_password_hash("dev123"),
            role=UserRole.DEVELOPER,
            organization_id=demo_org.id,
            is_active=True,
            is_verified=True,
        )
        db.add(dev_user)
        
        print(f"✓ Created developer user: {dev_user.email}")
        
        # Commit all changes
        db.commit()
        
        print("\n✅ Database seeded successfully!")
        print("\n📝 Demo Credentials:")
        print("   Admin:     admin@memgar.com / admin123")
        print("   Analyst:   analyst@memgar.com / analyst123")
        print("   Developer: developer@memgar.com / dev123")
        print("")
        
    except Exception as e:
        db.rollback()
        print(f"\n❌ Error seeding database: {e}")
        raise
    finally:
        db.close()


if __name__ == "__main__":
    seed_database()
