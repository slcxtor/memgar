"""
Memgar Enterprise - API Integration Tests
==========================================

Integration tests for API endpoints.
"""

import pytest
from fastapi import status


# =============================================================================
# HEALTH CHECK TESTS
# =============================================================================

@pytest.mark.integration
@pytest.mark.api
class TestHealthEndpoints:
    """Test health check endpoints."""
    
    def test_health_check(self, client):
        """Test health check endpoint."""
        response = client.get("/health")
        
        assert response.status_code == status.HTTP_200_OK
        data = response.json()
        assert data["status"] == "healthy"
        assert "version" in data
        assert "environment" in data
    
    def test_root_endpoint(self, client):
        """Test root endpoint."""
        response = client.get("/")
        
        assert response.status_code == status.HTTP_200_OK
        data = response.json()
        assert "message" in data
        assert "version" in data


# =============================================================================
# ANALYSIS ENDPOINT TESTS
# =============================================================================

@pytest.mark.integration
@pytest.mark.api
class TestAnalysisEndpoints:
    """Test analysis API endpoints."""
    
    def test_analyze_without_auth(self, client, malicious_content):
        """Test analysis without authentication (should fail)."""
        response = client.post(
            "/api/v1/analysis/analyze",
            json={"content": malicious_content}
        )
        
        assert response.status_code == status.HTTP_403_FORBIDDEN
    
    def test_analyze_malicious_content(self, client, auth_headers, malicious_content):
        """Test analysis of malicious content."""
        response = client.post(
            "/api/v1/analysis/analyze",
            json={"content": malicious_content},
            headers=auth_headers
        )
        
        assert response.status_code == status.HTTP_200_OK
        data = response.json()
        
        assert "decision" in data
        assert "risk_score" in data
        assert "threats" in data
        assert data["decision"] in ["allow", "block", "quarantine"]
        assert data["risk_score"] >= 0
        assert data["risk_score"] <= 100
    
    def test_analyze_safe_content(self, client, auth_headers, safe_content):
        """Test analysis of safe content."""
        response = client.post(
            "/api/v1/analysis/analyze",
            json={"content": safe_content},
            headers=auth_headers
        )
        
        assert response.status_code == status.HTTP_200_OK
        data = response.json()
        
        assert data["decision"] == "allow"
        assert data["risk_score"] == 0
        assert len(data["threats"]) == 0
    
    def test_batch_analysis(self, client, auth_headers, sample_threats):
        """Test batch analysis."""
        entries = [
            {"content": threat["content"]}
            for threat in sample_threats
        ]
        
        response = client.post(
            "/api/v1/analysis/analyze/batch",
            json={"entries": entries},
            headers=auth_headers
        )
        
        assert response.status_code == status.HTTP_200_OK
        data = response.json()
        
        assert "total_entries" in data
        assert "clean_entries" in data
        assert "threat_entries" in data
        assert data["total_entries"] == len(entries)
    
    def test_analysis_stats(self, client, auth_headers):
        """Test analysis statistics endpoint."""
        response = client.get(
            "/api/v1/analysis/stats",
            headers=auth_headers
        )
        
        assert response.status_code == status.HTTP_200_OK
        data = response.json()
        
        assert "total_analyses" in data
        assert "threats_detected" in data


# =============================================================================
# DASHBOARD ENDPOINT TESTS
# =============================================================================

@pytest.mark.integration
@pytest.mark.api
class TestDashboardEndpoints:
    """Test dashboard API endpoints."""
    
    def test_dashboard_overview_without_auth(self, client):
        """Test dashboard without authentication (should fail)."""
        response = client.get("/api/v1/dashboard/overview")
        
        assert response.status_code == status.HTTP_403_FORBIDDEN
    
    def test_dashboard_overview(self, client, auth_headers):
        """Test dashboard overview endpoint."""
        response = client.get(
            "/api/v1/dashboard/overview",
            headers=auth_headers
        )
        
        assert response.status_code == status.HTTP_200_OK
        data = response.json()
        
        assert "overview" in data
        assert "threat_by_severity" in data
        assert "threat_by_category" in data
        assert "analyses_timeline" in data
        assert "recent_threats" in data
    
    def test_dashboard_with_time_range(self, client, auth_headers):
        """Test dashboard with different time ranges."""
        time_ranges = ["1h", "6h", "24h", "7d", "30d"]
        
        for time_range in time_ranges:
            response = client.get(
                f"/api/v1/dashboard/overview?time_range={time_range}",
                headers=auth_headers
            )
            
            assert response.status_code == status.HTTP_200_OK
    
    def test_realtime_metrics(self, client, auth_headers):
        """Test real-time metrics endpoint."""
        response = client.get(
            "/api/v1/dashboard/metrics/realtime",
            headers=auth_headers
        )
        
        assert response.status_code == status.HTTP_200_OK
        data = response.json()
        
        assert "timestamp" in data
    
    def test_active_alerts(self, client, auth_headers):
        """Test active alerts endpoint."""
        response = client.get(
            "/api/v1/dashboard/alerts",
            headers=auth_headers
        )
        
        assert response.status_code == status.HTTP_200_OK
        data = response.json()
        
        assert "alerts" in data
        assert "total" in data


# =============================================================================
# AUTHORIZATION TESTS
# =============================================================================

@pytest.mark.integration
@pytest.mark.api
@pytest.mark.rbac
class TestAuthorization:
    """Test authorization and RBAC."""
    
    def test_admin_can_access_admin_endpoints(self, client, admin_auth_headers):
        """Test admin access to admin endpoints."""
        response = client.get(
            "/api/v1/admin/users",
            headers=admin_auth_headers
        )
        
        # Should succeed (even if empty)
        assert response.status_code in [status.HTTP_200_OK, status.HTTP_404_NOT_FOUND]
    
    def test_regular_user_cannot_access_admin_endpoints(self, client, auth_headers):
        """Test regular user cannot access admin endpoints."""
        response = client.get(
            "/api/v1/admin/users",
            headers=auth_headers
        )
        
        # Should fail with forbidden (if RBAC is enforced)
        # For now, may return 200 if RBAC not fully implemented
        assert response.status_code in [status.HTTP_200_OK, status.HTTP_403_FORBIDDEN]


# =============================================================================
# ERROR HANDLING TESTS
# =============================================================================

@pytest.mark.integration
@pytest.mark.api
class TestErrorHandling:
    """Test API error handling."""
    
    def test_invalid_endpoint(self, client):
        """Test 404 for invalid endpoint."""
        response = client.get("/api/v1/nonexistent")
        
        assert response.status_code == status.HTTP_404_NOT_FOUND
    
    def test_invalid_method(self, client, auth_headers):
        """Test 405 for invalid HTTP method."""
        response = client.put(
            "/api/v1/analysis/analyze",
            json={"content": "test"},
            headers=auth_headers
        )
        
        assert response.status_code == status.HTTP_405_METHOD_NOT_ALLOWED
    
    def test_invalid_json(self, client, auth_headers):
        """Test 422 for invalid JSON."""
        response = client.post(
            "/api/v1/analysis/analyze",
            data="invalid json",
            headers=auth_headers
        )
        
        assert response.status_code == status.HTTP_422_UNPROCESSABLE_ENTITY
    
    def test_missing_required_field(self, client, auth_headers):
        """Test 422 for missing required field."""
        response = client.post(
            "/api/v1/analysis/analyze",
            json={},  # Missing 'content' field
            headers=auth_headers
        )
        
        assert response.status_code == status.HTTP_422_UNPROCESSABLE_ENTITY
