"""
Memgar Enterprise - Authentication Tests
=========================================

Unit tests for JWT authentication and RBAC.
"""

import pytest
from datetime import datetime, timedelta

from app.auth.jwt import (
    create_access_token,
    create_refresh_token,
    decode_token,
    verify_token_type,
    get_password_hash,
    verify_password,
)
from app.auth.rbac import (
    Permission,
    UserRole,
    has_permission,
    is_admin,
    can_manage_users,
)


# =============================================================================
# PASSWORD HASHING TESTS
# =============================================================================

@pytest.mark.unit
@pytest.mark.auth
class TestPasswordHashing:
    """Test password hashing and verification."""
    
    def test_hash_password(self):
        """Test password hashing."""
        password = "test_password_123"
        hashed = get_password_hash(password)
        
        assert hashed != password
        assert len(hashed) > 0
        assert hashed.startswith("$2b$")
    
    def test_verify_correct_password(self):
        """Test verification with correct password."""
        password = "test_password_123"
        hashed = get_password_hash(password)
        
        assert verify_password(password, hashed) is True
    
    def test_verify_incorrect_password(self):
        """Test verification with incorrect password."""
        password = "test_password_123"
        wrong_password = "wrong_password"
        hashed = get_password_hash(password)
        
        assert verify_password(wrong_password, hashed) is False


# =============================================================================
# JWT TOKEN TESTS
# =============================================================================

@pytest.mark.unit
@pytest.mark.auth
class TestJWTTokens:
    """Test JWT token creation and validation."""
    
    def test_create_access_token(self):
        """Test access token creation."""
        data = {"sub": 123, "org_id": 456}
        token = create_access_token(data)
        
        assert token is not None
        assert len(token) > 0
        assert isinstance(token, str)
    
    def test_create_refresh_token(self):
        """Test refresh token creation."""
        data = {"sub": 123}
        token = create_refresh_token(data)
        
        assert token is not None
        assert len(token) > 0
    
    def test_decode_valid_token(self):
        """Test decoding valid token."""
        data = {"sub": 123, "org_id": 456}
        token = create_access_token(data)
        payload = decode_token(token)
        
        assert payload is not None
        assert payload["sub"] == 123
        assert payload["org_id"] == 456
        assert "exp" in payload
        assert "type" in payload
    
    def test_decode_invalid_token(self):
        """Test decoding invalid token."""
        invalid_token = "invalid.token.here"
        payload = decode_token(invalid_token)
        
        assert payload is None
    
    def test_verify_access_token_type(self):
        """Test verifying access token type."""
        data = {"sub": 123}
        token = create_access_token(data)
        payload = decode_token(token)
        
        assert verify_token_type(payload, "access") is True
        assert verify_token_type(payload, "refresh") is False
    
    def test_verify_refresh_token_type(self):
        """Test verifying refresh token type."""
        data = {"sub": 123}
        token = create_refresh_token(data)
        payload = decode_token(token)
        
        assert verify_token_type(payload, "refresh") is True
        assert verify_token_type(payload, "access") is False
    
    def test_token_expiration(self):
        """Test token with custom expiration."""
        data = {"sub": 123}
        expires_delta = timedelta(seconds=1)
        token = create_access_token(data, expires_delta)
        
        payload = decode_token(token)
        assert payload is not None
        
        # Token should expire after 1 second
        import time
        time.sleep(2)
        
        expired_payload = decode_token(token)
        assert expired_payload is None


# =============================================================================
# RBAC TESTS
# =============================================================================

@pytest.mark.unit
@pytest.mark.rbac
class TestRBAC:
    """Test Role-Based Access Control."""
    
    def test_admin_has_all_permissions(self):
        """Test that admin has all permissions."""
        assert has_permission(UserRole.ADMIN, Permission.ANALYSIS_READ)
        assert has_permission(UserRole.ADMIN, Permission.ANALYSIS_WRITE)
        assert has_permission(UserRole.ADMIN, Permission.USER_CREATE)
        assert has_permission(UserRole.ADMIN, Permission.SYSTEM_ADMIN)
    
    def test_user_limited_permissions(self):
        """Test that regular user has limited permissions."""
        assert has_permission(UserRole.USER, Permission.ANALYSIS_READ)
        assert has_permission(UserRole.USER, Permission.ANALYSIS_WRITE)
        assert not has_permission(UserRole.USER, Permission.USER_CREATE)
        assert not has_permission(UserRole.USER, Permission.SYSTEM_ADMIN)
    
    def test_security_analyst_permissions(self):
        """Test security analyst permissions."""
        assert has_permission(UserRole.SECURITY_ANALYST, Permission.ANALYSIS_READ)
        assert has_permission(UserRole.SECURITY_ANALYST, Permission.REPORT_CREATE)
        assert has_permission(UserRole.SECURITY_ANALYST, Permission.POLICY_UPDATE)
        assert not has_permission(UserRole.SECURITY_ANALYST, Permission.USER_CREATE)
    
    def test_developer_permissions(self):
        """Test developer permissions."""
        assert has_permission(UserRole.DEVELOPER, Permission.ANALYSIS_READ)
        assert has_permission(UserRole.DEVELOPER, Permission.APIKEY_CREATE)
        assert not has_permission(UserRole.DEVELOPER, Permission.USER_CREATE)
    
    def test_auditor_permissions(self):
        """Test auditor permissions (read-only)."""
        assert has_permission(UserRole.AUDITOR, Permission.ANALYSIS_READ)
        assert has_permission(UserRole.AUDITOR, Permission.AUDIT_VIEW)
        assert not has_permission(UserRole.AUDITOR, Permission.ANALYSIS_WRITE)
        assert not has_permission(UserRole.AUDITOR, Permission.POLICY_UPDATE)
    
    def test_is_admin(self):
        """Test admin check."""
        assert is_admin(UserRole.ADMIN) is True
        assert is_admin(UserRole.USER) is False
        assert is_admin(UserRole.SECURITY_ANALYST) is False
    
    def test_can_manage_users(self):
        """Test user management permission."""
        assert can_manage_users(UserRole.ADMIN) is True
        assert can_manage_users(UserRole.USER) is False
        assert can_manage_users(UserRole.DEVELOPER) is False


# =============================================================================
# INTEGRATION TESTS
# =============================================================================

@pytest.mark.integration
@pytest.mark.auth
class TestAuthenticationFlow:
    """Test complete authentication flow."""
    
    def test_full_token_lifecycle(self, test_user):
        """Test token creation, validation, and usage."""
        # Create tokens
        access_token = create_access_token(
            data={"sub": test_user.id, "org_id": test_user.organization_id}
        )
        refresh_token = create_refresh_token(
            data={"sub": test_user.id}
        )
        
        # Decode and validate
        access_payload = decode_token(access_token)
        refresh_payload = decode_token(refresh_token)
        
        assert access_payload is not None
        assert refresh_payload is not None
        
        assert verify_token_type(access_payload, "access")
        assert verify_token_type(refresh_payload, "refresh")
        
        assert access_payload["sub"] == test_user.id
        assert access_payload["org_id"] == test_user.organization_id
