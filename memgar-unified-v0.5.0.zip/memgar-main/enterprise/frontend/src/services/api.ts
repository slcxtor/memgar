/**
 * Memgar Enterprise - API Client
 * ===============================
 * 
 * Axios-based API client with authentication and error handling.
 */

import axios, { AxiosError, AxiosInstance, AxiosRequestConfig } from 'axios'
import type {
  AnalysisRequest,
  AnalysisResponse,
  DashboardData,
  LoginRequest,
  LoginResponse,
  ApiError,
} from '@/types'

// =============================================================================
// API CLIENT CONFIGURATION
// =============================================================================

const API_BASE_URL = import.meta.env.VITE_API_URL || 'http://localhost:8000'
const API_TIMEOUT = 30000 // 30 seconds

class ApiClient {
  private client: AxiosInstance
  private accessToken: string | null = null

  constructor() {
    this.client = axios.create({
      baseURL: API_BASE_URL,
      timeout: API_TIMEOUT,
      headers: {
        'Content-Type': 'application/json',
      },
    })

    // Load token from localStorage
    this.accessToken = localStorage.getItem('access_token')

    // Request interceptor - add auth token
    this.client.interceptors.request.use(
      (config) => {
        if (this.accessToken) {
          config.headers.Authorization = `Bearer ${this.accessToken}`
        }
        return config
      },
      (error) => Promise.reject(error)
    )

    // Response interceptor - handle errors
    this.client.interceptors.response.use(
      (response) => response,
      async (error: AxiosError<ApiError>) => {
        if (error.response?.status === 401) {
          // Token expired or invalid
          this.clearAuth()
          window.location.href = '/login'
        }
        return Promise.reject(error)
      }
    )
  }

  // ===========================================================================
  // AUTHENTICATION
  // ===========================================================================

  setAccessToken(token: string) {
    this.accessToken = token
    localStorage.setItem('access_token', token)
  }

  clearAuth() {
    this.accessToken = null
    localStorage.removeItem('access_token')
    localStorage.removeItem('user')
  }

  async login(credentials: LoginRequest): Promise<LoginResponse> {
    const response = await this.client.post<LoginResponse>(
      '/api/v1/auth/login',
      credentials
    )
    
    // Save token and user
    this.setAccessToken(response.data.access_token)
    localStorage.setItem('user', JSON.stringify(response.data.user))
    
    return response.data
  }

  async logout(): Promise<void> {
    try {
      await this.client.post('/api/v1/auth/logout')
    } finally {
      this.clearAuth()
    }
  }

  // ===========================================================================
  // ANALYSIS
  // ===========================================================================

  async analyzeContent(request: AnalysisRequest): Promise<AnalysisResponse> {
    const response = await this.client.post<AnalysisResponse>(
      '/api/v1/analysis/analyze',
      request
    )
    return response.data
  }

  async getAnalysisStats(): Promise<any> {
    const response = await this.client.get('/api/v1/analysis/stats')
    return response.data
  }

  // ===========================================================================
  // DASHBOARD
  // ===========================================================================

  async getDashboardData(timeRange: string = '24h'): Promise<DashboardData> {
    const response = await this.client.get<DashboardData>(
      '/api/v1/dashboard/overview',
      { params: { time_range: timeRange } }
    )
    return response.data
  }

  async getRealtimeMetrics(): Promise<any> {
    const response = await this.client.get('/api/v1/dashboard/metrics/realtime')
    return response.data
  }

  async getActiveAlerts(severity?: string, limit: number = 10): Promise<any> {
    const response = await this.client.get('/api/v1/dashboard/alerts', {
      params: { severity, limit },
    })
    return response.data
  }

  // ===========================================================================
  // REPORTS
  // ===========================================================================

  async listReports(): Promise<any> {
    const response = await this.client.get('/api/v1/reports')
    return response.data
  }

  async generateReport(config: any): Promise<any> {
    const response = await this.client.post('/api/v1/reports/generate', config)
    return response.data
  }

  // ===========================================================================
  // AUDIT
  // ===========================================================================

  async getAuditEvents(filters?: any): Promise<any> {
    const response = await this.client.get('/api/v1/audit/events', {
      params: filters,
    })
    return response.data
  }

  async exportAuditLogs(filters?: any): Promise<Blob> {
    const response = await this.client.get('/api/v1/audit/export', {
      params: filters,
      responseType: 'blob',
    })
    return response.data
  }

  // ===========================================================================
  // ADMIN
  // ===========================================================================

  async listUsers(): Promise<any> {
    const response = await this.client.get('/api/v1/admin/users')
    return response.data
  }

  async createUser(userData: any): Promise<any> {
    const response = await this.client.post('/api/v1/admin/users', userData)
    return response.data
  }

  async getOrganization(): Promise<any> {
    const response = await this.client.get('/api/v1/admin/organization')
    return response.data
  }

  async updateOrganizationSettings(settings: any): Promise<any> {
    const response = await this.client.put(
      '/api/v1/admin/organization/settings',
      settings
    )
    return response.data
  }
}

// Singleton instance
export const apiClient = new ApiClient()

// Error helper
export function getErrorMessage(error: unknown): string {
  if (axios.isAxiosError(error)) {
    const apiError = error.response?.data as ApiError | undefined
    return apiError?.detail || apiError?.error || error.message
  }
  return error instanceof Error ? error.message : 'An unknown error occurred'
}
