/**
 * Memgar Enterprise - TypeScript Types
 * =====================================
 * 
 * Type definitions for API requests and responses.
 */

// =============================================================================
// ENUMS
// =============================================================================

export enum Decision {
  ALLOW = 'allow',
  BLOCK = 'block',
  QUARANTINE = 'quarantine',
}

export enum Severity {
  CRITICAL = 'critical',
  HIGH = 'high',
  MEDIUM = 'medium',
  LOW = 'low',
  INFO = 'info',
}

export enum UserRole {
  ADMIN = 'admin',
  SECURITY_ANALYST = 'security_analyst',
  DEVELOPER = 'developer',
  AUDITOR = 'auditor',
  USER = 'user',
}

// =============================================================================
// ANALYSIS
// =============================================================================

export interface ThreatInfo {
  id: string
  name: string
  severity: Severity
  category: string
  matched_text: string
  confidence: number
}

export interface AnalysisRequest {
  content: string
  source_type?: string
  source_id?: string
  metadata?: Record<string, any>
}

export interface AnalysisResponse {
  request_id: string
  decision: Decision
  risk_score: number
  threat_count: number
  threats: ThreatInfo[]
  explanation: string
  analysis_time_ms: number
  layers_used: string[]
  timestamp: string
}

// =============================================================================
// DASHBOARD
// =============================================================================

export interface DashboardOverview {
  analyses_today: number
  threats_detected_today: number
  blocked_today: number
  avg_risk_score_today: number
  analyses_trend: number
  threats_trend: number
  total_analyses: number
  total_threats: number
  unique_threat_types: number
  avg_analysis_time_ms: number
  p95_analysis_time_ms: number
}

export interface ThreatDistribution {
  category: string
  count: number
  percentage: number
}

export interface TimeSeriesPoint {
  timestamp: string
  value: number
}

export interface RecentThreat {
  id: number
  timestamp: string
  threat_id: string
  threat_name: string
  severity: Severity
  risk_score: number
  content_preview: string
  source_type: string
}

export interface DashboardData {
  overview: DashboardOverview
  threat_by_severity: ThreatDistribution[]
  threat_by_category: ThreatDistribution[]
  analyses_timeline: TimeSeriesPoint[]
  threats_timeline: TimeSeriesPoint[]
  recent_threats: RecentThreat[]
}

// =============================================================================
// USER & AUTH
// =============================================================================

export interface User {
  id: number
  email: string
  username: string
  full_name?: string
  role: UserRole
  is_active: boolean
  created_at: string
}

export interface LoginRequest {
  email: string
  password: string
}

export interface LoginResponse {
  access_token: string
  refresh_token: string
  token_type: string
  user: User
}

// =============================================================================
// ORGANIZATION
// =============================================================================

export interface Organization {
  id: number
  name: string
  slug: string
  plan: string
  max_users: number
  max_api_calls_per_month: number
  is_active: boolean
}

// =============================================================================
// API RESPONSE
// =============================================================================

export interface ApiError {
  error: string
  detail?: string
  request_id?: string
}

export interface PaginatedResponse<T> {
  items: T[]
  total: number
  page: number
  page_size: number
  total_pages: number
}
