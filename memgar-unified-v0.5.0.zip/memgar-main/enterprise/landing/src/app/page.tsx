/**
 * Memgar.io - Landing Page
 * =========================
 * 
 * Professional landing page for Memgar Enterprise
 */

import { Shield, Zap, Lock, BarChart3, Users, Check } from 'lucide-react'

export default function Home() {
  return (
    <main className="min-h-screen bg-white">
      {/* Navigation */}
      <nav className="fixed top-0 w-full bg-white/80 backdrop-blur-md border-b border-gray-200 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <Shield className="h-8 w-8 text-blue-600" />
              <span className="ml-2 text-xl font-bold text-gray-900">Memgar</span>
            </div>
            <div className="hidden md:flex items-center space-x-8">
              <a href="#features" className="text-gray-600 hover:text-gray-900">Features</a>
              <a href="#pricing" className="text-gray-600 hover:text-gray-900">Pricing</a>
              <a href="#docs" className="text-gray-600 hover:text-gray-900">Docs</a>
              <a href="https://github.com/slck-tor/memgar" className="text-gray-600 hover:text-gray-900">
                GitHub
              </a>
            </div>
            <div className="flex items-center space-x-4">
              <a
                href="/login"
                className="text-gray-600 hover:text-gray-900"
              >
                Sign In
              </a>
              <a
                href="/signup"
                className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
              >
                Get Started
              </a>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="pt-32 pb-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto text-center">
          <div className="inline-flex items-center px-4 py-2 bg-blue-50 rounded-full mb-8">
            <span className="text-sm font-semibold text-blue-600">
              🚀 Now in Public Beta - v0.5.0
            </span>
          </div>
          
          <h1 className="text-5xl md:text-6xl font-bold text-gray-900 mb-6">
            Antivirus for
            <br />
            <span className="text-blue-600">AI Agent Memory</span>
          </h1>
          
          <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto">
            Protect your AI agents from memory poisoning attacks. 
            Detect and block prompt injection, credential theft, and data exfiltration 
            before they reach your agent's memory.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center mb-12">
            <a
              href="/signup"
              className="px-8 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 font-semibold text-lg"
            >
              Start Free Trial
            </a>
            <a
              href="#demo"
              className="px-8 py-3 border-2 border-gray-300 text-gray-900 rounded-lg hover:border-gray-400 font-semibold text-lg"
            >
              Watch Demo
            </a>
          </div>
          
          <div className="flex items-center justify-center gap-8 text-sm text-gray-600">
            <div className="flex items-center">
              <Check className="h-5 w-5 text-green-500 mr-2" />
              Free forever plan
            </div>
            <div className="flex items-center">
              <Check className="h-5 w-5 text-green-500 mr-2" />
              No credit card required
            </div>
            <div className="flex items-center">
              <Check className="h-5 w-5 text-green-500 mr-2" />
              Open source
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              4-Layer Defense Architecture
            </h2>
            <p className="text-xl text-gray-600">
              Comprehensive protection at every stage of memory processing
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            <FeatureCard
              icon={<Shield className="h-10 w-10 text-blue-600" />}
              title="Input Moderation"
              description="255 threat patterns with Aho-Corasick O(n) performance. Detects prompt injection, jailbreaks, and evasion techniques."
            />
            <FeatureCard
              icon={<Lock className="h-10 w-10 text-blue-600" />}
              title="Memory Sanitization"
              description="Strip malicious instructions, track content provenance, and ensure safe memory storage."
            />
            <FeatureCard
              icon={<Zap className="h-10 w-10 text-blue-600" />}
              title="Trust-Aware Retrieval"
              description="RAG security with temporal decay, anomaly detection, and trust scoring for retrieved content."
            />
            <FeatureCard
              icon={<BarChart3 className="h-10 w-10 text-blue-600" />}
              title="Behavioral Monitoring"
              description="Real-time monitoring, circuit breakers, and comprehensive audit logs for compliance."
            />
          </div>
        </div>
      </section>

      {/* Threat Coverage */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              Comprehensive Threat Coverage
            </h2>
            <p className="text-xl text-gray-600">
              14 threat categories, 255 patterns, 100% detection rate
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-6">
            <ThreatCard
              title="Financial Threats"
              items={['Payment redirection', 'IBAN fraud', 'Wire transfer manipulation']}
            />
            <ThreatCard
              title="Credential Theft"
              items={['Password extraction', 'Token stealing', 'API key leakage']}
            />
            <ThreatCard
              title="Data Exfiltration"
              items={['PII extraction', 'Database dumps', 'Secret exposure']}
            />
            <ThreatCard
              title="Sleeper Attacks"
              items={['Delayed payloads', 'Time bombs', 'Trigger conditions']}
            />
            <ThreatCard
              title="Advanced Evasion"
              items={['Many-shot jailbreak', 'Skeleton key', 'Unicode tricks']}
            />
            <ThreatCard
              title="Multi-Modal"
              items={['Image steganography', 'PDF poisoning', 'Audio attacks']}
            />
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section id="pricing" className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              Simple, Transparent Pricing
            </h2>
            <p className="text-xl text-gray-600">
              Start free, scale as you grow
            </p>
          </div>

          <div className="grid md:grid-cols-4 gap-8">
            <PricingCard
              name="Free"
              price="$0"
              description="Perfect for trying out Memgar"
              features={[
                '1,000 analyses/month',
                'Core threat detection',
                'Community support',
                'Open source',
              ]}
              cta="Start Free"
              highlighted={false}
            />
            <PricingCard
              name="Developer"
              price="$29"
              description="For individual developers"
              features={[
                '50,000 analyses/month',
                'Advanced threats',
                'Email support',
                'API access',
              ]}
              cta="Get Started"
              highlighted={false}
            />
            <PricingCard
              name="Business"
              price="$299"
              description="For growing teams"
              features={[
                '500,000 analyses/month',
                'Dashboard & reports',
                'RBAC & audit logs',
                'Priority support',
              ]}
              cta="Start Trial"
              highlighted={true}
            />
            <PricingCard
              name="Enterprise"
              price="Custom"
              description="For large organizations"
              features={[
                'Unlimited analyses',
                'Custom integrations',
                'SLA & compliance',
                'Dedicated support',
              ]}
              cta="Contact Sales"
              highlighted={false}
            />
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-blue-600">
        <div className="max-w-4xl mx-auto text-center px-4">
          <h2 className="text-4xl font-bold text-white mb-4">
            Ready to Secure Your AI Agents?
          </h2>
          <p className="text-xl text-blue-100 mb-8">
            Join hundreds of developers protecting their AI agents with Memgar
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a
              href="/signup"
              className="px-8 py-3 bg-white text-blue-600 rounded-lg hover:bg-gray-100 font-semibold text-lg"
            >
              Start Free Trial
            </a>
            <a
              href="https://docs.memgar.com"
              className="px-8 py-3 border-2 border-white text-white rounded-lg hover:bg-blue-700 font-semibold text-lg"
            >
              Read Documentation
            </a>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 bg-gray-900 text-gray-400">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-4 gap-8 mb-8">
            <div>
              <div className="flex items-center mb-4">
                <Shield className="h-6 w-6 text-blue-500" />
                <span className="ml-2 text-lg font-bold text-white">Memgar</span>
              </div>
              <p className="text-sm">
                AI Agent Memory Security Platform
              </p>
            </div>
            <div>
              <h3 className="text-white font-semibold mb-4">Product</h3>
              <ul className="space-y-2 text-sm">
                <li><a href="#features">Features</a></li>
                <li><a href="#pricing">Pricing</a></li>
                <li><a href="/changelog">Changelog</a></li>
              </ul>
            </div>
            <div>
              <h3 className="text-white font-semibold mb-4">Developers</h3>
              <ul className="space-y-2 text-sm">
                <li><a href="https://docs.memgar.com">Documentation</a></li>
                <li><a href="https://github.com/slck-tor/memgar">GitHub</a></li>
                <li><a href="/api">API Reference</a></li>
              </ul>
            </div>
            <div>
              <h3 className="text-white font-semibold mb-4">Company</h3>
              <ul className="space-y-2 text-sm">
                <li><a href="/about">About</a></li>
                <li><a href="/blog">Blog</a></li>
                <li><a href="/contact">Contact</a></li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-800 pt-8 text-center text-sm">
            <p>&copy; 2026 Memgar. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </main>
  )
}

// Helper Components
function FeatureCard({ icon, title, description }: any) {
  return (
    <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
      <div className="mb-4">{icon}</div>
      <h3 className="text-lg font-semibold text-gray-900 mb-2">{title}</h3>
      <p className="text-gray-600">{description}</p>
    </div>
  )
}

function ThreatCard({ title, items }: any) {
  return (
    <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
      <h3 className="text-lg font-semibold text-gray-900 mb-4">{title}</h3>
      <ul className="space-y-2">
        {items.map((item: string, i: number) => (
          <li key={i} className="flex items-start text-sm text-gray-600">
            <Check className="h-4 w-4 text-green-500 mr-2 mt-0.5 flex-shrink-0" />
            {item}
          </li>
        ))}
      </ul>
    </div>
  )
}

function PricingCard({ name, price, description, features, cta, highlighted }: any) {
  return (
    <div
      className={`bg-white p-8 rounded-lg ${
        highlighted
          ? 'border-2 border-blue-600 shadow-xl'
          : 'border border-gray-200 shadow-sm'
      }`}
    >
      <h3 className="text-xl font-bold text-gray-900 mb-2">{name}</h3>
      <div className="mb-4">
        <span className="text-4xl font-bold text-gray-900">{price}</span>
        {price !== 'Custom' && <span className="text-gray-600">/month</span>}
      </div>
      <p className="text-gray-600 mb-6">{description}</p>
      <ul className="space-y-3 mb-8">
        {features.map((feature: string, i: number) => (
          <li key={i} className="flex items-start text-sm text-gray-600">
            <Check className="h-5 w-5 text-green-500 mr-2 flex-shrink-0" />
            {feature}
          </li>
        ))}
      </ul>
      <a
        href="/signup"
        className={`block w-full text-center px-4 py-2 rounded-lg font-semibold ${
          highlighted
            ? 'bg-blue-600 text-white hover:bg-blue-700'
            : 'bg-gray-100 text-gray-900 hover:bg-gray-200'
        }`}
      >
        {cta}
      </a>
    </div>
  )
}
